document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("mustangForm");
    const mustangCheck = document.getElementById("mustangCheck");
    const mustangDetails = document.getElementById("mustangDetails");
    const responseDiv = document.getElementById("response");

    async function loadDropdownOptions() {
        try {
            const response = await fetch("options.json"); // External file containing dropdown data
            const data = await response.json();
            const issueTypeDropdown = document.getElementById("issueType");

            data.issues.forEach(issue => {
                let option = document.createElement("option");
                option.value = issue.value;
                option.textContent = issue.label;
                issueTypeDropdown.appendChild(option);
            });
        } catch (error) {
            console.error("Error loading dropdown options:", error);
        }
    }

    async function loadIssueDetails(issueType) {
        try {
            const response = await fetch("options.json");
            const data = await response.json();
            const issueDetailsBox = document.getElementById("issueDetails");

            issueDetailsBox.value = data.issueDescriptions[issueType] || "Please describe your issue in detail.";
        } catch (error) {
            console.error("Error loading issue details:", error);
        }
    }

    mustangCheck.addEventListener("change", function () {
        if (mustangCheck.value === "yes") {
            mustangDetails.style.display = "block";
            responseDiv.innerHTML = "";
        } else {
            mustangDetails.style.display = "none";
            responseDiv.innerHTML = "<p>Don't bring it in. We only service Mustangs.</p>";
        }
    });

    document.getElementById("issueType").addEventListener("change", function () {
        loadIssueDetails(this.value);
    });

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        if (mustangCheck.value === "no") {
            responseDiv.innerHTML = "<p>Don't bring it in. We only service Mustangs.</p>";
            return;
        }

        const makeModel = document.getElementById("makeModel").value;
        const issueType = document.getElementById("issueType").value;
        const issueDetails = document.getElementById("issueDetails").value;

        responseDiv.innerHTML = `
            <h2>Service Request Submitted</h2>
            <p><strong>Make/Model:</strong> ${makeModel}</p>
            <p><strong>Issue Type:</strong> ${issueType}</p>
            <p><strong>Details:</strong> ${issueDetails}</p>
            <p>Please bring your Mustang to Mustang Magic at 160 Brook Avenue, Deer Park, New York, 11729 for a thorough inspection.</p>
        `;
    });

    loadDropdownOptions();
});
